
package controller;

import LoginScreen.GUI.GUIController;
import View.View;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


/**
 *
 * @author KrzysieK
 */
public class Program extends Application {
    
    public static void main(String[] args) {
      Application.launch(args);
   }
   @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource(
            "GUI.fxml"
          )
        );
        
        stage.setScene(
          new Scene(
            (Pane) loader.load()
          )
        );
        
        GUIController controller = loader.<GUIController>getController();
        controller.setStage(stage);
        stage.show();
    }
    
}
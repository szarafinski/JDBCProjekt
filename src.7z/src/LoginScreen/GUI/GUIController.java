package LoginScreen.GUI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import LoginScreen.model.UserCatalog;
import LoginScreen.model.DatabaseUser;
import LoginScreen.model.ObjectFactory;
import View.View;
import javafx.stage.Stage;

/**
 *
 * @author Kacper
 */
public class GUIController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    TableView tableView;
    @FXML
    TableColumn userNameColumn;
    @FXML
    TableColumn passwordColumn;
    @FXML
    TextField userNameTextField;
    @FXML
    TextField passwordTextField;
    
    Stage stage;
    private ObservableList<DatabaseUser> users = FXCollections.observableArrayList();
    
    private static final Logger log = Logger.getLogger(GUIController.class.getName());
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tableView.setEditable(true);
        
        userNameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        userNameColumn.setOnEditCommit(new EventHandler<CellEditEvent<DatabaseUser, String>>() {
        @Override
        public void handle(CellEditEvent<DatabaseUser, String> t) {
            DatabaseUser user = t.getRowValue();
            String newTitle = t.getNewValue();
            user.setUserName(newTitle);
        }
        });
        
        passwordColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        passwordColumn.setOnEditCommit(new EventHandler<CellEditEvent<DatabaseUser, String>>() {
        @Override
        public void handle(CellEditEvent<DatabaseUser, String> t) {
            DatabaseUser user = t.getRowValue();
            String newAuthor = t.getNewValue();
            user.setPassword(newAuthor);
        }
        });
    }    
    
    private void loadCatalog() {
        File file = new File("./test.xml");
        if (file != null) {
            try {
                JAXBContext context = JAXBContext.newInstance(ObjectFactory.class.getPackage().getName());
                Unmarshaller unmarshaller = context.createUnmarshaller();
                UserCatalog catalog = (UserCatalog) unmarshaller.unmarshal(file);
                users.clear();
                users.addAll(catalog.getUsers());
                tableView.setItems(users);
            } catch (JAXBException ex) {
                log.log(Level.WARNING, ex.getMessage(), ex);
            }
        }
    }
    
    private void saveCatalog(){
        File file = new File("./test.xml");
        if (file != null) {
            try {
                JAXBContext context = JAXBContext.newInstance(ObjectFactory.class.getPackage().getName());
                Marshaller marshaller = context.createMarshaller();
                UserCatalog cat = new UserCatalog();
                cat.setUsers(new HashSet<>(users));
                marshaller.marshal(cat, file);
            } catch (JAXBException ex) {
                log.log(Level.WARNING, ex.getMessage(), ex);
            }
        }
    }
    
    @FXML
    private void saveCatalogAction(ActionEvent event) {
        loadCatalog();
        if(!userNameTextField.getText().equals("") && !passwordTextField.getText().equals("")){
            for(DatabaseUser user : users){
                if(user.getUserName().equals(userNameTextField.getText()))
                    return;
            }
            DatabaseUser user = new DatabaseUser(userNameTextField.getText(),passwordTextField.getText());
            users.add(user);
        }
        saveCatalog();
    }
    
    @FXML
    private void delRow(ActionEvent event){
        int index = tableView.getSelectionModel().getSelectedIndex();
        users.remove(index);
        saveCatalog();
    }
    
    @FXML
    private void login(ActionEvent event){
        loadCatalog();
        String username = userNameTextField.getText();
        String password = passwordTextField.getText();
        for(DatabaseUser user : users){
            if(username.equals(user.getUserName()) &&
               password.equals(user.getPassword())){
                View projektZespolowy = new View();
                projektZespolowy.start(stage);
                break;
            }
        }
    }
    
    public void setStage(Stage s){
        stage = s;
    }
}

package LoginScreen.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kacper
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name = "DatabaseUser", propOrder = {"userName","password"})

public class DatabaseUser implements Comparable<DatabaseUser>{
    private String userName;
    private String password;
    
    @Override
    public int compareTo(DatabaseUser t){
        return this.userName.compareTo(t.userName);
    }
    
    public DatabaseUser(){
        
    }
    
    public DatabaseUser(String a, String b){
        userName = a;
        password = b;
    }
    
    public void setUserName(String a){
        userName = a;
    }
    
    public void setPassword(String a){
        password = a;
    }
    @XmlAttribute
    public String getUserName(){
        return userName;
    }
    @XmlAttribute
    public String getPassword(){
        return password;
    }
}

package LoginScreen.model;



import java.util.HashSet;
import java.util.Set;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Kacper
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"users"})
@XmlRootElement(name = "UserCatalog")
public class UserCatalog {

    @XmlElement(required = true, name = "DatabaseUser")
    private Set<DatabaseUser> users = new HashSet<>();

    public UserCatalog() {
    }

    public UserCatalog(Set<DatabaseUser> users) {
        this.users = users;
    }

    public Set<DatabaseUser> getUsers() {
        return users;
    }

    public void setUsers(Set<DatabaseUser> users) {
        this.users = users;
    }
}

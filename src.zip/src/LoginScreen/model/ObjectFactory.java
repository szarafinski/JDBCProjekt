package LoginScreen.model;



import javax.xml.bind.annotation.XmlRegistry;

/**
 *
 * @author Kacper
 */
@XmlRegistry
public class ObjectFactory {

    public ObjectFactory() {
    }

    public UserCatalog createUserCatalog() {
        return new UserCatalog();
    }
    
    public DatabaseUser createBook(){
        return new DatabaseUser();
    }
}
